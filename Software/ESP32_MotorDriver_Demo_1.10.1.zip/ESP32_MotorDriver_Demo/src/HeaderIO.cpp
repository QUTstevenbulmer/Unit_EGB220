#include "HeaderIO.h"
#include "Log.h"
#include <Wire.h>
#include "pins.h"

// Controller header pin  ->  breakout board function (from both schematics)
const HeaderPin HEADER_PINS[] = {
    // gpio header pin   breakout use (BOB v03)
    { 17, "J4",  1, "LED blue"           },
    { 18, "J4",  2, "LED yellow"         },
    {  8, "J4",  3, "Line sensor LF_4"   },
    {  3, "J4",  4, "Line sensor LF_3"   },
    {  9, "J4",  5, "Button SW1"         },
    {  4, "J6",  2, "Line sensor LF_8"   },
    {  5, "J6",  3, "Line sensor LF_7"   },
    {  6, "J6",  4, "Line sensor LF_6"   },
    {  7, "J6",  5, "Line sensor LF_5"   },
    { 15, "J6",  6, "Encoder A - ch B"   },
    { 16, "J6",  7, "Encoder A - ch A"   },
    {  1, "J7",  2, "Line sensor LF_1"   },
    {  2, "J7",  3, "Line sensor LF_2"   },
    { 43, "J7",  4, "UART TX (J14)"      },
    { 44, "J7",  5, "UART RX (J14)"      },
    { 42, "J7",  6, "Servo 1 (J8)"       },
    { 41, "J7",  7, "Servo 2 (J9)"       },
    { 40, "J7",  8, "LED red"            },
    { 39, "J7",  9, "LED green"          },
    { 34, "J7", 12, "I2C SDA (OLED)"     },
    { 33, "J7", 13, "I2C SCL (OLED)"     },
    { 13, "J7", 14, "Button SW2"         },
    { 12, "J7", 15, "Encoder B - ch A"   },
    { 11, "J7", 16, "Encoder B - ch B"   },
};
const size_t HEADER_PIN_COUNT = sizeof(HEADER_PINS) / sizeof(HEADER_PINS[0]);

const HeaderPin* findHeaderPin(uint8_t gpio) {
    for (size_t i = 0; i < HEADER_PIN_COUNT; i++)
        if (HEADER_PINS[i].gpio == gpio) return &HEADER_PINS[i];
    return nullptr;
}

void headerPrintTable() {
    Log.println(F("\r\n  Ctrl header  Pin  GPIO  Breakout board use"));
    Log.println(F("  -----------  ---  ----  ------------------"));
    for (size_t i = 0; i < HEADER_PIN_COUNT; i++) {
        const HeaderPin& p = HEADER_PINS[i];
        Log.printf("  %-11s  %3u  IO%-2u  %s\r\n", p.header, p.pin, p.gpio, p.bob);
    }
    Log.println(F("  Motor pins: PWMA 10, AIN1 21, AIN2 14, PWMB 38, BIN1 36, BIN2 37, STBY 35"));
}

// NOTE: these raw tests take a pin away from its normal job until reboot.
void headerBlink(uint8_t gpio, uint32_t ms) {
    pinMode(gpio, OUTPUT);
    uint32_t start = millis();
    while (millis() - start < ms) {
        digitalWrite(gpio, HIGH); delay(250);
        digitalWrite(gpio, LOW);  delay(250);
    }
    pinMode(gpio, INPUT);
}

void headerBlinkAll(uint32_t msEach) {
    Log.println(F("Blinking each header pin in turn (LED + 330R to GND, or a meter)."));
    Log.println(F("Press any key to stop. Reboot afterwards to restore normal use."));
    for (size_t i = 0; i < HEADER_PIN_COUNT; i++) {
        const HeaderPin& p = HEADER_PINS[i];
        Log.printf("  %s pin %-2u (IO%u)  %s\r\n", p.header, p.pin, p.gpio, p.bob);
        headerBlink(p.gpio, msEach);
        if (Serial.available()) { while (Serial.available()) Serial.read(); break; }
    }
    Log.println(F("Done."));
}

void headerReadDigital() {
    Log.println(F("Raw digital levels of every header pin:"));
    for (size_t i = 0; i < HEADER_PIN_COUNT; i++) {
        const HeaderPin& p = HEADER_PINS[i];
        Log.printf("  %s-%-2u IO%-2u = %d   %s\r\n", p.header, p.pin, p.gpio,
                      digitalRead(p.gpio), p.bob);
    }
}

// Uses the Wire bus already started in setup() (shared with the OLED).
void i2cScan() {
    Log.printf("Scanning I2C on SDA=IO%u SCL=IO%u ...\r\n", PIN_I2C_SDA, PIN_I2C_SCL);
    int found = 0;
    for (uint8_t addr = 1; addr < 127; addr++) {
        Wire.beginTransmission(addr);
        if (Wire.endTransmission() == 0) {
            Log.printf("  found device at 0x%02X%s\r\n", addr,
                          addr == 0x3C ? "  (OLED display)" : "");
            found++;
        }
    }
    if (!found) Log.println(F("  nothing found"));
}
